// Blocks configuration for dual monitor setup
// Monitor: 0 = primary (laptop) - all stats except time
//          1 = secondary (external) - only time

static const Block blocks[] = {
    // ===== PRIMARY MONITOR (0) - ALL STATS EXCEPT TIME =====
    
    // Memory usage - No icon
    {"", "free -h | awk '/^Mem:/ {print $3\"/\"$2}'", 5, 0, 0},
    
    // Bluetooth - Icon: 󰂯 (connected) / 󰂲 (not connected)
    {"", "bluetoothctl info | grep -q 'Connected: yes' && echo '󰂯' || echo '󰂲'", 10, 11, 0},
    
    // Volume -  with percentage if sound, 󰝟 if muted/no sound
    {"", "wpctl get-volume @DEFAULT_SINK@ 2>/dev/null | grep -q '[MUTED]' && echo '󰝟' || (wpctl get-volume @DEFAULT_SINK@ 2>/dev/null | awk '{vol=int($2*100); if(vol==0) print \"󰝟\"; else print \" \" vol \"%\"}' || echo '󰝟')", 1, 10, 0},
    
    // WiFi - No icon if connected, 󰤭 if not connected
    {"", "nmcli -t -f active,ssid dev wifi | grep '^yes' | cut -d: -f2 || echo '󰤭'", 10, 0, 0},
    
    // Battery - Icon: 󰁹
    {"󰁹 ", "upower -i /org/freedesktop/UPower/devices/battery_BAT0 2>/dev/null | grep -E 'percentage' | awk '{print $2}' || echo 'AC'", 30, 0, 0},
    
    // ===== SECONDARY MONITOR (1) - ONLY TIME =====
    
    // Time - Icon: 
    {" ", "date '+%H:%M'", 60, 0, 1},
};

// Delimiter between status items
static char delim[] = " | ";
static unsigned int delimLen = 5;
