CURRENT_SINK=$(wpctl inspect @DEFAULT_AUDIO_SINK@ | grep "node.description" | cut -d'"' -f2)

# Return short name
if echo "$CURRENT_SINK" | grep -iq "headphone\|headset"; then
    echo "Headphones"
elif echo "$CURRENT_SINK" | grep -iq "speaker"; then
    echo "Speakers"
else
    # Fallback: return first word of description
    echo "$CURRENT_SINK" | awk '{print $1}'
fi
