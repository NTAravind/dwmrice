# Toggle between available audio sinks (fixed version)
CURRENT_SINK=$(wpctl inspect @DEFAULT_AUDIO_SINK@ | grep "node.name" | cut -d'"' -f2)
SINKS=($(wpctl status | awk '/Sinks:/,/Sources:/' | grep -E "^\s+[0-9]+\." | awk '{print $2}' | tr -d '.'))

# Find current sink index in the list
current_index=0
for i in "${!SINKS[@]}"; do
    SINK_NAME=$(wpctl inspect ${SINKS[$i]} | grep "node.name" | cut -d'"' -f2)
    if [ "$SINK_NAME" = "$CURRENT_SINK" ]; then
        current_index=$i
        break
    fi
done

# Switch to next sink (circular)
next_index=$(( (current_index + 1) % ${#SINKS[@]} ))
next_sink_id="${SINKS[$next_index]}"

# Set the new default sink
wpctl set-default "$next_sink_id"

# Get friendly name for notification
SINK_DESC=$(wpctl inspect "$next_sink_id" | grep "node.description" | cut -d'"' -f2)
notify-send "Audio Output" "Switched to: $SINK_DESC" -t 2000


