#!/bin/bash
# Setup sudoers for passwordless CPU governor changes
# Run with: sudo bash setup-sudoers.sh

if [ "$EUID" -ne 0 ]; then
    echo "Please run as root: sudo bash $0"
    exit 1
fi

SUDOERS_FILE="/etc/sudoers.d/eww-battery-profile"

# Get the actual username (not root)
ACTUAL_USER=${SUDO_USER:-$USER}

echo "Creating sudoers file for user: $ACTUAL_USER"

# Create sudoers file
cat > "$SUDOERS_FILE" << EOF
# Allow $ACTUAL_USER to change CPU governor without password
$ACTUAL_USER ALL=(ALL) NOPASSWD: /usr/bin/tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor
$ACTUAL_USER ALL=(ALL) NOPASSWD: /usr/bin/systemctl restart auto-cpufreq
$ACTUAL_USER ALL=(ALL) NOPASSWD: /usr/bin/systemctl start auto-cpufreq
$ACTUAL_USER ALL=(ALL) NOPASSWD: /usr/bin/systemctl stop auto-cpufreq
EOF

# Set proper permissions
chmod 0440 "$SUDOERS_FILE"

# Validate sudoers file
if visudo -c -f "$SUDOERS_FILE"; then
    echo "✓ Sudoers file created successfully at $SUDOERS_FILE"
    echo "✓ User $ACTUAL_USER can now change CPU profiles without password"
else
    echo "✗ Error: Invalid sudoers file, removing it"
    rm "$SUDOERS_FILE"
    exit 1
fi

echo ""
echo "Setup complete! The battery profile button will now work."
