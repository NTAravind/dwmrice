#!/bin/bash
# Timer status script for EWW
# Place in ~/.config/eww/scripts/timer-status.sh

TIMER_FILE="/tmp/eww-timer-remaining"
STATE_FILE="/tmp/eww-timer-state"

case "$1" in
    display)
        # Show timer display
        if [ -f "$TIMER_FILE" ]; then
            seconds=$(cat "$TIMER_FILE")
            minutes=$((seconds / 60))
            secs=$((seconds % 60))
            printf "%02d:%02d" $minutes $secs
        else
            echo "25:00"
        fi
        ;;
        
    running)
        # Check if timer is running
        if [ -f "$STATE_FILE" ]; then
            state=$(cat "$STATE_FILE")
            if [ "$state" = "running" ]; then
                echo "true"
            else
                echo "false"
            fi
        else
            echo "false"
        fi
        ;;
        
    state)
        # Get current state
        if [ -f "$STATE_FILE" ]; then
            cat "$STATE_FILE"
        else
            echo "stopped"
        fi
        ;;
esac
