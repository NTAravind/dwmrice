#!/bin/bash
# ~/.config/eww/scripts/wifi-connect.sh

# Input is the SSID (escaped with || for colons)
SSID=$(echo "$1" | sed 's/||/:/g')

if [ -z "$SSID" ]; then
    notify-send "WiFi Connection" "Error: No SSID provided"
    exit 1
fi

# Check if connection already exists
if nmcli con show | grep -q "$SSID"; then
    nmcli dev wifi connect "$SSID" && {
        notify-send "WiFi Connection" "Connected to $SSID"
        exit 0
    }
fi

# Prompt for password if network is secured
SECURITY=$(nmcli -t -f ssid,security dev wifi | grep "^$SSID:" | cut -d: -f2)
if [ -n "$SECURITY" ] && [ "$SECURITY" != "--" ]; then
    PASSWORD=$(zenity --password --title "Enter Password for $SSID" 2>/dev/null)
    if [ -z "$PASSWORD" ]; then
        notify-send "WiFi Connection" "No password provided for $SSID"
        exit 1
    fi
    nmcli dev wifi connect "$SSID" password "$PASSWORD" && {
        notify-send "WiFi Connection" "Connected to $SSID"
        exit 0
    } || {
        notify-send "WiFi Connection" "Failed to connect to $SSID"
        exit 1
    }
else
    nmcli dev wifi connect "$SSID" && {
        notify-send "WiFi Connection" "Connected to $SSID"
        exit 0
    } || {
        notify-send "WiFi Connection" "Failed to connect to $SSID"
        exit 1
    }
fi