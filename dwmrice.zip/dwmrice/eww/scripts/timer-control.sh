#!/bin/bash
# Pomodoro-style productivity timer for EWW
# Place in ~/.config/eww/scripts/timer-control.sh

TIMER_FILE="/tmp/eww-timer-remaining"
STATE_FILE="/tmp/eww-timer-state"
PID_FILE="/tmp/eww-timer-pid"

# Default: 25 minutes for work session
WORK_TIME=1500
BREAK_TIME=300

start_timer() {
    local duration=$1
    local mode=$2
    
    # Kill any existing timer
    if [ -f "$PID_FILE" ]; then
        kill "$(cat "$PID_FILE")" 2>/dev/null
    fi
    
    echo "running" > "$STATE_FILE"
    echo "$duration" > "$TIMER_FILE"
    
    # Start countdown in background
    (
        echo $$ > "$PID_FILE"
        remaining=$duration
        
        while [ $remaining -gt 0 ]; do
            # Check if paused or stopped
            if [ ! -f "$STATE_FILE" ]; then
                exit 0
            fi
            
            state=$(cat "$STATE_FILE")
            if [ "$state" = "paused" ]; then
                # Save remaining time and wait
                echo "$remaining" > "$TIMER_FILE"
                sleep 1
                continue
            fi
            
            if [ "$state" != "running" ]; then
                exit 0
            fi
            
            sleep 1
            remaining=$((remaining - 1))
            echo "$remaining" > "$TIMER_FILE"
        done
        
        # Timer finished
        if [ "$mode" = "work" ]; then
            notify-send "Pomodoro Timer" "Work session complete! Time for a break 🎉" -u critical -t 10000
        else
            notify-send "Pomodoro Timer" "Break's over! Ready to work? 💪" -u critical -t 10000
        fi
        
        # Clean up
        rm -f "$TIMER_FILE" "$STATE_FILE" "$PID_FILE"
    ) &
}

case "$1" in
    toggle)
        if [ -f "$STATE_FILE" ]; then
            state=$(cat "$STATE_FILE")
            if [ "$state" = "running" ]; then
                # Pause
                echo "paused" > "$STATE_FILE"
            elif [ "$state" = "paused" ]; then
                # Resume
                echo "running" > "$STATE_FILE"
            fi
        else
            # Start new work session
            start_timer $WORK_TIME "work"
        fi
        ;;
        
    reset)
        # Stop and reset timer
        if [ -f "$PID_FILE" ]; then
            kill "$(cat "$PID_FILE")" 2>/dev/null
        fi
        rm -f "$TIMER_FILE" "$STATE_FILE" "$PID_FILE"
        ;;
        
    break)
        # Start break session
        if [ -f "$PID_FILE" ]; then
            kill "$(cat "$PID_FILE")" 2>/dev/null
        fi
        start_timer $BREAK_TIME "break"
        ;;
        
    work)
        # Start work session
        if [ -f "$PID_FILE" ]; then
            kill "$(cat "$PID_FILE")" 2>/dev/null
        fi
        start_timer $WORK_TIME "work"
        ;;
esac
