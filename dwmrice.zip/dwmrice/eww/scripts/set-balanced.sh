#!/bin/bash
# Set CPU governor to balanced mode
# Tries schedutil first, falls back to ondemand

if grep -q "schedutil" /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors 2>/dev/null; then
    echo "schedutil" | sudo tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor > /dev/null 2>&1
else
    echo "ondemand" | sudo tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor > /dev/null 2>&1
fi

if [ $? -eq 0 ]; then
    notify-send "CPU Profile" "⚖️ Switched to Balanced mode" -u normal
else
    notify-send "CPU Profile" "Failed to change profile. Check sudoers setup." -u critical
fi