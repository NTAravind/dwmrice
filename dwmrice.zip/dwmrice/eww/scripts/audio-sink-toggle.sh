#!/bin/bash
# FILE: toggle-audio-output.sh
# Toggle between Speaker (ID 59) and Leaf Bass Bluetooth (ID 84)

# Define sink IDs for speaker and Bluetooth headphones
SPEAKER_SINK_ID="59"
BLUETOOTH_SINK_ID="84"

# Get the current default sink's ID
CURRENT_SINK_ID=$(wpctl inspect @DEFAULT_AUDIO_SINK@ | grep "id =" | awk '{print $3}')

if [ -z "$CURRENT_SINK_ID" ]; then
    notify-send "Audio Output" "Error: Could not determine current audio sink" -t 2000
    exit 1
fi

# Determine the next sink to switch to
if [ "$CURRENT_SINK_ID" = "$SPEAKER_SINK_ID" ]; then
    NEXT_SINK_ID="$BLUETOOTH_SINK_ID"
    NEXT_SINK_NAME="Leaf Bass"
else
    NEXT_SINK_ID="$SPEAKER_SINK_ID"
    NEXT_SINK_NAME="Speaker"
fi

# Set the new default sink
if ! wpctl set-default "$NEXT_SINK_ID"; then
    notify-send "Audio Output" "Error: Failed to switch to $NEXT_SINK_NAME" -t 2000
    exit 1
fi

# Notify user of the switch
notify-send "Audio Output" "Switched to: $NEXT_SINK_NAME" -t 2000
