#!/bin/bash
# Script to get battery percentage of connected Bluetooth device
# Save this as: ~/.config/eww/scripts/bt-battery.sh
# Make executable: chmod +x ~/.config/eww/scripts/bt-battery.sh

# Get the MAC address of the first connected device
connected_device=$(bluetoothctl devices Connected 2>/dev/null | head -1 | awk '{print $2}')

if [ -z "$connected_device" ]; then
    echo ""
    exit 0
fi

# Try to get battery info using bluetoothctl
battery=$(bluetoothctl info "$connected_device" 2>/dev/null | grep -i "Battery Percentage" | awk -F'[()]' '{print $2}' | tr -d ' ')

# If bluetoothctl doesn't work, try upower
if [ -z "$battery" ]; then
    # Find the device in upower
    device_path=$(upower -e | grep -i "$connected_device" | head -1)
    if [ -n "$device_path" ]; then
        battery=$(upower -i "$device_path" | grep percentage | awk '{print $2}' | tr -d '%')
    fi
fi

# Output the battery percentage or empty string
if [ -n "$battery" ]; then
    echo "$battery"
else
    echo ""
fi