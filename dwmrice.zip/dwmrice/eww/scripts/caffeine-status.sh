if [ -f "/tmp/eww_caffeine_active" ]; then
    echo "true"
else
    echo "false"
fi

