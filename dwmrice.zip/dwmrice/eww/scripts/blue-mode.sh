#!/bin/bash
# Check if redshift is running
if pgrep -x redshift > /dev/null; then
    # Kill redshift
    pkill redshift
    # Reset gamma
    redshift -x
    notify-send "Blue Light Filter" "Disabled" -u normal
else
    # Start redshift with 4000K temperature
    redshift -O 4000 &
    notify-send "Blue Light Filter" "Enabled (4000K)" -u normal
fi
