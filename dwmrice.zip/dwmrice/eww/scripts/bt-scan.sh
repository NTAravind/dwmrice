#!/bin/bash
# ~/.config/eww/scripts/bt-scan.sh
# Scans and saves discovered devices in real-time

CACHE_FILE="/tmp/bt_discovered_devices"
SCAN_LOG="/tmp/bt_scan.log"
SCAN_DURATION=12  # Scan for 12 seconds

# Ensure Bluetooth is powered on
if ! bluetoothctl show | grep -q 'Powered: yes'; then
    notify-send "Bluetooth" "Bluetooth is off"
    echo "[]" > "$CACHE_FILE"
    exit 1
fi

# Clear cache and log
> "$CACHE_FILE"
> "$SCAN_LOG"

notify-send "Bluetooth" "Scanning for devices..."

# Start scanning in background
bluetoothctl --timeout "$SCAN_DURATION" scan on > "$SCAN_LOG" 2>&1 &
SCAN_PID=$!

# Give it a moment to start
sleep 1

# Get list of known/paired devices first
bluetoothctl devices 2>/dev/null | while read -r _ mac name; do
    if [ -n "$name" ] && [ -n "$mac" ]; then
        # Check if it's a paired device
        if bluetoothctl info "$mac" 2>/dev/null | grep -q "Paired: yes"; then
            echo "PAIRED:$name" >> "$CACHE_FILE"
        else
            echo "KNOWN:$name" >> "$CACHE_FILE"
        fi
    fi
done

# Wait for scan to complete
wait $SCAN_PID 2>/dev/null

# Stop scanning explicitly
bluetoothctl scan off >/dev/null 2>&1

# Process the log file for any new devices
if [ -f "$SCAN_LOG" ]; then
    grep -E "\[NEW\]|\[CHG\]" "$SCAN_LOG" | while read -r line; do
        # Extract MAC address (case insensitive)
        if echo "$line" | grep -qiE "Device [0-9A-Fa-f:]{17}"; then
            mac=$(echo "$line" | grep -oiE "[0-9A-Fa-f:]{17}" | head -1)
            
            # Get device name from bluetoothctl
            device_info=$(bluetoothctl info "$mac" 2>/dev/null)
            if [ -n "$device_info" ]; then
                name=$(echo "$device_info" | grep "Name:" | cut -d: -f2- | xargs)
                
                if [ -n "$name" ]; then
                    # Check if paired
                    if echo "$device_info" | grep -q "Paired: yes"; then
                        echo "PAIRED:$name" >> "$CACHE_FILE"
                    else
                        echo "KNOWN:$name" >> "$CACHE_FILE"
                    fi
                fi
            fi
        fi
    done
fi

# Remove duplicates and count
if [ -s "$CACHE_FILE" ]; then
    sort -u "$CACHE_FILE" -o "$CACHE_FILE"
    device_count=$(wc -l < "$CACHE_FILE")
    notify-send "Bluetooth" "Found $device_count device(s)"
else
    notify-send "Bluetooth" "No devices found"
    echo "[]" > "$CACHE_FILE"
fi

# Clean up
rm -f "$SCAN_LOG"