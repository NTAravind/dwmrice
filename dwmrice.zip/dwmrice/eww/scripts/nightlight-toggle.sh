#!/usr/bin/env bash
# nightlight-toggle.sh
# Toggle a nightlight using redshift. If gammastep is running it will stop it.
# Exits with a one-line stdout: "true" if nightlight is ON after the toggle, "false" otherwise.
# Place in: ~/.config/eww/scripts/nightlight-toggle.sh
set -euo pipefail

# configuration: adjust temperature and brightness (0.1 - 1.0)
TEMP=3700       # color temperature in Kelvin when enabled
BRIGHTNESS=0.85 # daytime:1.0 ; night: 0.85

# helper: notify (no-op if notify-send missing)
_notify() {
  if command -v notify-send >/dev/null 2>&1; then
    notify-send "Night Light" "$1"
  fi
}

# find running processes
is_running() {
  pgrep -x "$1" >/dev/null 2>&1
}

# stop gammastep if it's running (some users use gammastep)
if is_running gammastep; then
  pkill -x gammastep || true
  # small pause so redshift can start cleanly afterwards
  sleep 0.15
fi

# toggle redshift
if command -v redshift >/dev/null 2>&1; then
  if is_running redshift; then
    # turn off: kill redshift and reset color
    pkill -x redshift || true
    # run a reset just in case (safe no-op if no X)
    redshift -x >/dev/null 2>&1 || true
    _notify "Night light disabled"
    printf "false"
    exit 0
  else
    # start redshift as a background daemon with fixed temperature/brightness
    # -l 0:0 uses "manual" location (no location-based shift) and -t t:t sets day:night same here
    # setsid detaches it so it survives if the caller exits
    setsid redshift -l 0:0 -t "${TEMP}:${TEMP}" -b "${BRIGHTNESS}:1.0" >/dev/null 2>&1 &
    sleep 0.1
    if is_running redshift; then
      _notify "Night light enabled (redshift ${TEMP}K)"
      printf "true"
      exit 0
    else
      _notify "Failed to start redshift"
      printf "false"
      exit 1
    fi
  fi
else
  # redshift not installed — suggest installation or fallback to gammastep
  _notify "redshift not found. Install package 'redshift' or adapt to gammastep."
  printf "false"
  exit 2
fi
