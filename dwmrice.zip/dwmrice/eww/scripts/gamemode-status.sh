# ============================================
# Check if game mode is active
if [ -f "/tmp/eww_gamemode_active" ]; then
    echo "true"
else
    echo "false"
fi

