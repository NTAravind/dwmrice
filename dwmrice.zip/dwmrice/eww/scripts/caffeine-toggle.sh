CAFFEINE_FILE="/tmp/eww_caffeine_active"
CAFFEINE_PID_FILE="/tmp/eww_caffeine_pid"

if [ -f "$CAFFEINE_FILE" ]; then
    # Disable caffeine
    if [ -f "$CAFFEINE_PID_FILE" ]; then
        kill $(cat "$CAFFEINE_PID_FILE") 2>/dev/null
        rm "$CAFFEINE_PID_FILE"
    fi
    rm "$CAFFEINE_FILE"
    notify-send "Caffeine Mode" "Disabled - Power saving restored" -t 2000
else
    # Enable caffeine - prevent system from sleeping
    # Using systemd-inhibit to block idle/sleep
    systemd-inhibit --what=idle:sleep:handle-lid-switch --who="EWW Caffeine" --why="User requested" sleep infinity &
    echo $! > "$CAFFEINE_PID_FILE"
    touch "$CAFFEINE_FILE"
    notify-send "Caffeine Mode" "Enabled - Screen won't sleep" -t 2000
fi

