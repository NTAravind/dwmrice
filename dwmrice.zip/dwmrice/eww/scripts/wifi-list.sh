#!/usr/bin/env bash
# ~/.config/eww/scripts/wifi-list.sh
# Output WiFi networks in EWW-friendly JSON array format

set -eo pipefail

if ! nmcli radio wifi | grep -qi 'enabled'; then
    echo '[]'
    exit 0
fi

nmcli device wifi rescan >/dev/null 2>&1 || true
sleep 1

# Build JSON array using jq for proper formatting
nmcli -t -f SSID,SIGNAL,SECURITY device wifi list 2>/dev/null | \
    grep -v '^$' | \
    grep -v '^--:' | \
    awk -F: '
    BEGIN { 
        printf "["
        first=1
    }
    $1 != "" && $1 != "--" {
        # Reconstruct SSID (may contain colons)
        ssid = $1
        for(i=2; i<=NF-2; i++) {
            ssid = ssid ":" $i
        }
        signal = $(NF-1)
        security = $NF
        
        # Escape quotes in SSID
        gsub(/"/, "\\\"", ssid)
        gsub(/"/, "\\\"", security)
        
        if(!first) printf ","
        first=0
        printf "{\"ssid\":\"%s\",\"signal\":%d,\"security\":\"%s\"}", ssid, signal, security
    }
    END { printf "]" }'