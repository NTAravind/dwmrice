# Toggle game mode (gamemoderun + picom compositor)
GAMEMODE_FILE="/tmp/eww_gamemode_active"

if [ -f "$GAMEMODE_FILE" ]; then
    # Disable game mode
    # Re-enable picom
    picom --config ~/.config/picom/picom.conf &
    rm "$GAMEMODE_FILE"
    notify-send "Game Mode" "Disabled - Compositor restored" -t 2000
else
    # Enable game mode
    # Kill picom (compositor)
    pkill picom
    touch "$GAMEMODE_FILE"
    notify-send "Game Mode" "Enabled - Compositor disabled" -t 2000
fi
