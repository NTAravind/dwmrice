#!/bin/bash
# ~/.config/eww/scripts/bt-connect.sh
# Connect to a Bluetooth device by name

DEVICE_NAME="$1"

if [ -z "$DEVICE_NAME" ]; then
    notify-send "Bluetooth" "No device name provided"
    exit 1
fi

# Find device MAC address by name
MAC_ADDRESS=$(bluetoothctl devices 2>/dev/null | grep -F "$DEVICE_NAME" | grep -oiE "[0-9A-Fa-f:]{17}" | head -1)

if [ -z "$MAC_ADDRESS" ]; then
    notify-send "Bluetooth" "Device '$DEVICE_NAME' not found"
    exit 1
fi

# Check if already connected
if bluetoothctl info "$MAC_ADDRESS" 2>/dev/null | grep -q "Connected: yes"; then
    # Disconnect
    notify-send "Bluetooth" "Disconnecting from $DEVICE_NAME..."
    if bluetoothctl disconnect "$MAC_ADDRESS" >/dev/null 2>&1; then
        notify-send "Bluetooth" "Disconnected from $DEVICE_NAME"
    else
        notify-send "Bluetooth" "Failed to disconnect"
    fi
else
    # Check if device is paired
    if ! bluetoothctl info "$MAC_ADDRESS" 2>/dev/null | grep -q "Paired: yes"; then
        # Need to pair first
        notify-send "Bluetooth" "Pairing with $DEVICE_NAME..."
        if bluetoothctl pair "$MAC_ADDRESS" >/dev/null 2>&1; then
            # Trust the device
            bluetoothctl trust "$MAC_ADDRESS" >/dev/null 2>&1
            notify-send "Bluetooth" "Paired successfully"
        else
            notify-send "Bluetooth" "Pairing failed"
            exit 1
        fi
    fi
    
    # Connect
    notify-send "Bluetooth" "Connecting to $DEVICE_NAME..."
    if bluetoothctl connect "$MAC_ADDRESS" >/dev/null 2>&1; then
        notify-send "Bluetooth" "Connected to $DEVICE_NAME"
    else
        notify-send "Bluetooth" "Connection failed"
        exit 1
    fi
fi