#!/bin/bash
# ~/.config/eww/scripts/bt-list.sh
# Shows discovered devices from scan cache + paired devices
# Returns JSON array of objects: [{"name": "Device Name", "paired": true}, ...]

CACHE_FILE="/tmp/bt_discovered_devices"
CACHE_MAX_AGE=60  # Cache valid for 60 seconds

# Check if Bluetooth is powered on
if ! bluetoothctl show | grep -q 'Powered: yes'; then
    echo "[]"
    exit 0
fi

# Function to build JSON object
build_json_object() {
    local name="$1"
    local paired="$2"
    # Escape quotes and backslashes for JSON
    name=$(echo "$name" | sed 's/\\/\\\\/g; s/"/\\"/g')
    echo "{\"name\":\"$name\",\"paired\":$paired}"
}

# If cache doesn't exist or is too old, return paired devices only
if [ ! -f "$CACHE_FILE" ]; then
    devices=$(bluetoothctl devices Paired 2>/dev/null | while read -r _ mac name; do
        if [ -n "$name" ]; then
            build_json_object "$name" "true"
        fi
    done | paste -sd, -)
    
    if [ -n "$devices" ]; then
        echo "[$devices]"
    else
        echo "[]"
    fi
    exit 0
fi

# Check cache age
CACHE_AGE=$(($(date +%s) - $(stat -c %Y "$CACHE_FILE" 2>/dev/null || echo 0)))
if [ $CACHE_AGE -ge $CACHE_MAX_AGE ]; then
    devices=$(bluetoothctl devices Paired 2>/dev/null | while read -r _ mac name; do
        if [ -n "$name" ]; then
            build_json_object "$name" "true"
        fi
    done | paste -sd, -)
    
    if [ -n "$devices" ]; then
        echo "[$devices]"
    else
        echo "[]"
    fi
    exit 0
fi

# Read cache and build JSON array
devices=""
while IFS=: read -r status name; do
    if [ -n "$name" ]; then
        if [ "$status" = "PAIRED" ]; then
            device_obj=$(build_json_object "$name" "true")
        else
            device_obj=$(build_json_object "$name" "false")
        fi
        
        if [ -z "$devices" ]; then
            devices="$device_obj"
        else
            devices="$devices,$device_obj"
        fi
    fi
done < "$CACHE_FILE"

# Output JSON array
if [ -n "$devices" ]; then
    echo "[$devices]"
else
    echo "[]"
fi