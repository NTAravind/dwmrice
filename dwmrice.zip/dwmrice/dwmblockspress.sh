#!/bin/bash
# Automated installation script for enhanced dwmblocks
# Run this from the directory containing all the files

set -e

echo "🚀 Enhanced dwmblocks Installation Script"
echo "=========================================="

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running as root
if [ "$EUID" -eq 0 ]; then 
    echo -e "${RED}Don't run this script as root!${NC}"
    exit 1
fi

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Step 1: Install dependencies
echo -e "\n${YELLOW}Step 1: Checking dependencies...${NC}"
MISSING_DEPS=()

for dep in nmcli bluetoothctl pamixer sensors; do
    if ! command_exists $dep; then
        MISSING_DEPS+=($dep)
    fi
done

if [ ${#MISSING_DEPS[@]} -gt 0 ]; then
    echo -e "${YELLOW}Missing dependencies: ${MISSING_DEPS[*]}${NC}"
    echo "Install with:"
    echo "  Arch: sudo pacman -S networkmanager bluez bluez-utils pamixer lm_sensors"
    echo "  Debian/Ubuntu: sudo apt install network-manager bluez pamixer lm-sensors"
    read -p "Continue anyway? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Step 2: Install statusbar scripts
echo -e "\n${YELLOW}Step 2: Installing statusbar scripts...${NC}"
mkdir -p ~/.local/bin

for script in sb-volume sb-wifi sb-bluetooth; do
    if [ -f "$script" ]; then
        cp "$script" ~/.local/bin/
        chmod +x ~/.local/bin/$script
        echo -e "${GREEN}✓${NC} Installed $script"
    else
        echo -e "${RED}✗${NC} $script not found"
    fi
done

# Step 3: Apply dwmblocks patch
echo -e "\n${YELLOW}Step 3: Patching dwmblocks...${NC}"
read -p "Enter path to your dwmblocks directory: " DWMBLOCKS_DIR
DWMBLOCKS_DIR="${DWMBLOCKS_DIR/#\~/$HOME}"

if [ ! -d "$DWMBLOCKS_DIR" ]; then
    echo -e "${RED}Directory not found: $DWMBLOCKS_DIR${NC}"
    exit 1
fi

cd "$DWMBLOCKS_DIR"

if [ -f "dwmblocks-statuscmd-b6b0be4.diff" ] || [ -f "../dwmblocks-statuscmd-b6b0be4.diff" ]; then
    PATCH_FILE="dwmblocks-statuscmd-b6b0be4.diff"
    [ ! -f "$PATCH_FILE" ] && PATCH_FILE="../dwmblocks-statuscmd-b6b0be4.diff"
    
    echo "Applying statuscmd patch..."
    if patch -p1 < "$PATCH_FILE"; then
        echo -e "${GREEN}✓${NC} Patch applied successfully"
    else
        echo -e "${YELLOW}⚠${NC} Patch might already be applied or failed"
        read -p "Continue anyway? (y/N) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
else
    echo -e "${YELLOW}⚠${NC} Patch file not found, skipping..."
fi

# Step 4: Copy blocks.h configuration
echo -e "\n${YELLOW}Step 4: Installing blocks.h configuration...${NC}"
if [ -f "blocks.h.bak" ]; then
    echo -e "${YELLOW}⚠${NC} Backup already exists, skipping backup"
else
    if [ -f "blocks.h" ]; then
        cp blocks.h blocks.h.bak
        echo -e "${GREEN}✓${NC} Original blocks.h backed up to blocks.h.bak"
    fi
fi

if [ -f "../blocks.h" ]; then
    cp ../blocks.h .
    echo -e "${GREEN}✓${NC} New blocks.h installed"
elif [ -f "blocks.h.new" ]; then
    cp blocks.h.new blocks.h
    echo -e "${GREEN}✓${NC} New blocks.h installed"
else
    echo -e "${RED}✗${NC} blocks.h not found. Please copy it manually."
fi

# Step 5: Compile dwmblocks
echo -e "\n${YELLOW}Step 5: Compiling dwmblocks...${NC}"
if make clean && make; then
    echo -e "${GREEN}✓${NC} dwmblocks compiled successfully"
    
    read -p "Install to /usr/local/bin? (requires sudo) (Y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Nn]$ ]]; then
        sudo make install
        echo -e "${GREEN}✓${NC} dwmblocks installed"
    fi
else
    echo -e "${RED}✗${NC} Compilation failed"
    exit 1
fi

# Step 6: Apply dwm patch
echo -e "\n${YELLOW}Step 6: Patching dwm...${NC}"
read -p "Enter path to your dwm directory (or skip): " DWM_DIR
DWM_DIR="${DWM_DIR/#\~/$HOME}"

if [ -n "$DWM_DIR" ] && [ -d "$DWM_DIR" ]; then
    cd "$DWM_DIR"
    
    STATUSCMD_PATCH="dwm-statuscmd-20210405-67d76bd.diff"
    
    if [ ! -f "$STATUSCMD_PATCH" ]; then
        echo "Downloading dwm statuscmd patch..."
        wget -q https://dwm.suckless.org/patches/statuscmd/$STATUSCMD_PATCH
    fi
    
    echo "Applying dwm statuscmd patch..."
    if patch -p1 < "$STATUSCMD_PATCH"; then
        echo -e "${GREEN}✓${NC} dwm patch applied successfully"
        
        # Compile dwm
        echo "Compiling dwm..."
        if make clean && make; then
            echo -e "${GREEN}✓${NC} dwm compiled successfully"
            
            read -p "Install dwm? (requires sudo) (Y/n) " -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Nn]$ ]]; then
                sudo make install
                echo -e "${GREEN}✓${NC} dwm installed"
            fi
        else
            echo -e "${RED}✗${NC} dwm compilation failed"
        fi
    else
        echo -e "${YELLOW}⚠${NC} dwm patch might already be applied or failed"
    fi
else
    echo -e "${YELLOW}⚠${NC} Skipping dwm patch"
fi

# Step 7: Setup autostart
echo -e "\n${YELLOW}Step 7: Setting up autostart...${NC}"
XINITRC="$HOME/.xinitrc"

if [ -f "$XINITRC" ]; then
    if grep -q "dwmblocks" "$XINITRC"; then
        echo -e "${GREEN}✓${NC} dwmblocks already in .xinitrc"
    else
        echo -e "\n# Start dwmblocks statusbar" >> "$XINITRC"
        echo "dwmblocks &" >> "$XINITRC"
        echo -e "${GREEN}✓${NC} Added dwmblocks to .xinitrc"
    fi
else
    echo -e "${YELLOW}⚠${NC} .xinitrc not found. Add 'dwmblocks &' manually to your X startup."
fi

# Final instructions
echo -e "\n${GREEN}========================================${NC}"
echo -e "${GREEN}✨ Installation Complete! ✨${NC}"
echo -e "${GREEN}========================================${NC}"
echo -e "\nNext steps:"
echo "1. Restart dwmblocks: pkill dwmblocks && dwmblocks &"
echo "2. Restart dwm (usually Mod+Shift+Q)"
echo "3. Test clicking on WiFi and Bluetooth icons"
echo -e "\n${YELLOW}Font Requirements:${NC}"
echo "Make sure you have Nerd Fonts installed:"
echo "  Arch: yay -S nerd-fonts-complete"
echo "  Or install JetBrainsMono Nerd Font manually"
echo -e "\n${YELLOW}Troubleshooting:${NC}"
echo "• Test scripts: ~/.local/bin/sb-wifi"
echo "• Test signals: pkill -RTMIN+6 dwmblocks"
echo "• Check logs: journalctl --user -xe"
echo -e "\nEnjoy your enhanced dwmblocks! 🎉"
