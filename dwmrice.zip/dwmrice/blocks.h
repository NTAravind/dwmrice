// Modify this file to change what commands output to your statusbar
// Monitor: 0 = primary (laptop), 1 = secondary (external)

static const Block blocks[] = {
    // Primary monitor (0) - All stats EXCEPT time
    
    // CPU usage
    {"  ", "top -bn1 | grep 'Cpu(s)' | sed 's/.*, *\\([0-9.]*\\)%* id.*/\\1/' | awk '{print 100 - $1\"%\"}'", 3, 0, 0},
    
    // Memory usage
    {"  ", "free -h | awk '/^Mem:/ {print $3\"/\"$2}'", 5, 0, 0},
    
    // Disk usage
    {"  ", "df -h / | awk 'NR==2 {print $3\"/\"$2\" (\"$5\")\"}'", 60, 0, 0},
    
    // Battery
    {"  ", "cat /sys/class/power_supply/BAT*/capacity 2>/dev/null || echo 'AC'", 30, 0, 0},
    
    // Volume
    {"  ", "amixer get Master | tail -1 | awk '{print $5}' | tr -d '[]'", 1, 10, 0},
    
    // Network
    {"  ", "nmcli -t -f active,ssid dev wifi | grep '^yes' | cut -d: -f2 || echo 'Disconnected'", 10, 0, 0},
    
    // Temperature
    {" ", "sensors 2>/dev/null | awk '/^Core 0/ {print $3}' | head -1 || echo 'N/A'", 5, 0, 0},
    
    // Secondary monitor (1) - ONLY time
    {"  ", "date '+%H:%M'", 60, 0, 1},
};

// Set delimiter between status commands. NULL character ('\0') means no delimiter.
static char delim[] = " | ";
static unsigned int delimLen = 3;