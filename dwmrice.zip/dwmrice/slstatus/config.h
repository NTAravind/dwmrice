/* config.h for slstatus */
#ifndef CONFIG_H
#define CONFIG_H

/* See LICENSE file for copyright and license details. */

/* interval between updates (in ms) */
const unsigned int interval = 1000;

/* text to show if no value can be retrieved */
static const char unknown_str[] = "n/a";

/* maximum output string length */
#define MAXLEN 2048
/* Solo mode configuration */
static const struct arg args[] = {
    { run_command, " %s ", "free -h | awk '/^Mem/{printf(\"%.1fG/%.1fG\", $3/1024/1024, $2/1024/1024)}'" },
    { run_command, "%s ", "nmcli radio wifi | grep -q enabled && nmcli -t -f STATE dev | grep -q connected && echo '' || echo ''" },
    { run_command, "%s ", "bluetoothctl show | grep -q 'Powered: yes' && echo '' || echo ''" },
    { run_command, " %s%% ", "cat /sys/class/power_supply/BAT0/capacity" },
    { datetime, " %s", "%Y-%m-%d %H:%M" },
};

#endif
