#!/bin/bash
# Script to update EWW colors from pywal
# Place in ~/.config/eww/scripts/update-colors.sh
# Run after changing wallpaper with pywal

COLORS_FILE="$HOME/.cache/wal/colors"
EWW_SCSS="$HOME/.config/eww/eww.scss"

if [ ! -f "$COLORS_FILE" ]; then
    echo "Pywal colors file not found!"
    exit 1
fi

# Read colors from pywal
BG=$(sed -n '1p' "$COLORS_FILE")
FG=$(sed -n '8p' "$COLORS_FILE")
ACCENT=$(sed -n '2p' "$COLORS_FILE")
COLOR3=$(sed -n '4p' "$COLORS_FILE")

# Create the CSS with pywal colors
cat > "$EWW_SCSS" << EOF
/* EWW Widget Styles - Auto-generated from pywal */

@define-color bg ${BG};
@define-color fg ${FG};
@define-color accent ${ACCENT};
@define-color color3 ${COLOR3};

* {
  all: unset;
  font-family: "JetBrainsMono Nerd Font";
  font-size: 14px;
}

.main-container {
  background-color: @bg;
  border: 2px solid @fg;
  padding: 0;
}

/* Timer Widget */
.timer-box {
  background-color: alpha(@fg, 0.1);
  padding: 15px;
  border-bottom: 2px solid @fg;
}

.timer-label {
  font-size: 24px;
  color: @fg;
  font-weight: bold;
  padding-right: 20px;
}

.timer-controls {
  padding-left: 10px;
}

.timer-btn {
  background-color: alpha(@fg, 0.15);
  color: @fg;
  padding: 10px 15px;
  margin-left: 5px;
  border: 1px solid @fg;
  font-size: 16px;
  font-weight: bold;
}

.timer-btn:hover {
  background-color: alpha(@accent, 0.3);
}

/* Quick Settings */
.quick-settings {
  padding: 10px;
  border-bottom: 2px solid @fg;
}

.setting-btn {
  background-color: alpha(@fg, 0.1);
  color: @fg;
  padding: 20px;
  margin: 5px;
  border: 1px solid @fg;
  min-width: 80px;
  font-size: 13px;
}

.setting-btn:hover {
  background-color: alpha(@accent, 0.2);
}

.wifi-btn, .bluet-btn {
  font-size: 16px;
  font-weight: bold;
}

.blue-mode-btn {
  font-size: 12px;
}

/* Date Display */
.date-box {
  background-color: alpha(@fg, 0.05);
  padding: 100px 20px;
  border-bottom: 2px solid @fg;
}

.date-label {
  font-size: 16px;
  color: @fg;
}

/* Music Player */
.music-box {
  padding: 20px;
  border-bottom: 2px solid @fg;
  background-color: alpha(@fg, 0.05);
}

.song-info {
  flex: 1;
  padding-right: 15px;
}

.song-title {
  font-size: 16px;
  font-weight: bold;
  color: @fg;
  margin-bottom: 5px;
}

.song-artist {
  font-size: 13px;
  color: alpha(@fg, 0.7);
  margin-bottom: 10px;
}

.progress-box {
  margin-top: 10px;
}

.song-progress {
  min-width: 300px;
}

.song-progress trough {
  background-color: alpha(@fg, 0.2);
  min-height: 6px;
  border-radius: 3px;
}

.song-progress highlight {
  background-color: @accent;
  border-radius: 3px;
}

.music-controls {
  padding-left: 10px;
}

.music-btn {
  background-color: alpha(@fg, 0.15);
  color: @fg;
  padding: 10px 15px;
  margin: 3px 0;
  border: 1px solid @fg;
  min-width: 40px;
  font-size: 14px;
  font-weight: bold;
}

.music-btn:hover {
  background-color: alpha(@accent, 0.3);
}

/* Sliders */
.slider-box {
  padding: 15px 20px;
  border-bottom: 2px solid @fg;
  background-color: alpha(@fg, 0.05);
}

.slider-label {
  color: @fg;
  font-size: 14px;
  min-width: 150px;
}

.volume-scale, .brightness-scale {
  min-width: 350px;
}

.volume-scale trough, .brightness-scale trough {
  background-color: alpha(@fg, 0.2);
  min-height: 8px;
  border-radius: 4px;
}

.volume-scale highlight, .brightness-scale highlight {
  background-color: @accent;
  border-radius: 4px;
}

.volume-scale slider, .brightness-scale slider {
  background-color: @fg;
  border-radius: 50%;
  min-width: 18px;
  min-height: 18px;
}

/* System Info */
.disk-box {
  padding: 15px 20px;
  border-bottom: 2px solid @fg;
  background-color: alpha(@fg, 0.05);
}

.system-box {
  padding: 15px 20px;
  background-color: alpha(@fg, 0.05);
}

.disk-label {
  color: @fg;
  font-size: 14px;
}

.profile-info {
  margin-left: auto;
}

.info-label {
  color: @fg;
  font-size: 12px;
  padding-right: 10px;
}

.info-buttons {
  padding-left: 10px;
}

.sys-btn {
  background-color: alpha(@fg, 0.15);
  color: @fg;
  padding: 8px 15px;
  margin-left: 5px;
  border: 1px solid @fg;
  font-size: 12px;
  font-weight: bold;
}

.sys-btn:hover {
  background-color: alpha(@accent, 0.3);
}
EOF

# Reload EWW
eww reload

echo "EWW colors updated from pywal!"
