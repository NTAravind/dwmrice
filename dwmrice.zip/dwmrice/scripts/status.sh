#!/bin/bash
LAPTOP="eDP-1"
EXTERNAL="HDMI-1"
pkill slstatus
if xrandr | grep -q "^$EXTERNAL connected"; then
    slstatus -s -c ~/.config/slstatus/config_docked.h | while read -r line; do
        xsetroot -name ";$line"
    done &
else
    slstatus -s -c ~/.config/slstatus/config_solo.h | while read -r line; do
        xsetroot -name ";$line"
    done &
fi
