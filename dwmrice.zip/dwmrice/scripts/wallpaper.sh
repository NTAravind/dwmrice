#!/bin/bash
# Random wallpaper setter for DWM using feh

WALL_DIR="$HOME/.config/wallpaper"

# check if folder exists
[ -d "$WALL_DIR" ] || exit 1

# pick a random file (jpg/png only)
PIC=$(find "$WALL_DIR" -type f \( -iname "*.jpg" -o -iname "*.png" -o -iname "*.jpeg" \) | shuf -n 1)

# set with feh (fill screen)
[ -n "$PIC" ] && feh --bg-fill "$PIC"

