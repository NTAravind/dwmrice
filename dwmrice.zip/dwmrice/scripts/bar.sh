#!/bin/bash
# ~/.dwm/bar-launch.sh - Lemonbar for laptop-only bar with docked/solo modes

LAPTOP="eDP-1"      # Laptop output (confirm with xrandr --query)
EXTERNAL="HDMI-1"   # External output
FONT="xft:JetBrainsMono Nerd Font:size=10"
BG="#222222"        # Dark background
FG="#ffffff"        # Light foreground
WIDTH=1200          # Compact width (62.5% of 1920)
HEIGHT=30           # Bar height
LAPTOP_WIDTH=1920   # Your laptop resolution
X=$(( (LAPTOP_WIDTH - WIDTH) / 2 ))  # Center the bar
Y=0                 # Top (set to 1050 for bottom)

# Get DWM tags
get_tags() {
    dwm-msg get_tags 2>/dev/null | jq -r '.[] | .name + (if .selected then "*" else (if .occupied then "o" else "" end) end) + (if .urgent then "!" else "" end)' | tr '\n' ' ' || echo "1-9"
}

# Get WiFi status ( connected,  off) using nmcli
get_wifi() {
    if nmcli radio wifi | grep -q enabled && nmcli -t -f STATE dev | grep -q connected; then
        echo ""
    else
        echo ""
    fi
}

# Get Bluetooth status ( on/connected,  off)
get_bluetooth() {
    if bluetoothctl show | grep -q "Powered: yes"; then
        if bluetoothctl info | grep -q "Connected: yes"; then
            echo ""
        else
            echo ""
        fi
    else
        echo ""
    fi
}

# Get RAM usage ( used/total)
get_ram() {
    echo " $(free -h | awk '/^Mem/{print $3 "/" $2}')"
}

# Get date/time ( YYYY-MM-DD HH:MM)
get_datetime() {
    echo " $(date '+%Y-%m-%d %H:%M')"
}

# Get docked indicator ( Docked)
get_docked() {
    echo " Docked"
}

# Get battery status ( capacity%)
get_battery() {
    CAPACITY=$(cat /sys/class/power_supply/BAT0/capacity 2>/dev/null || echo "N/A")
    echo " ${CAPACITY}%"
}

# Status for docked mode
gen_with_ext() {
    while true; do
        TAGS=$(get_tags)
        RAM=$(get_ram)
        WIFI=$(get_wifi)
        BT=$(get_bluetooth)
        DOCKED=$(get_docked)
        DATETIME=$(get_datetime)
        echo "%{lFg$FG B$BG} $TAGS %{rFg$FG B$BG} $RAM | $WIFI | $BT | $DOCKED | $DATETIME "
        sleep 1
    done
}

# Status for solo mode
gen_no_ext() {
    while true; do
        TAGS=$(get_tags)
        RAM=$(get_ram)
        WIFI=$(get_wifi)
        BT=$(get_bluetooth)
        BAT=$(get_battery)
        DATETIME=$(get_datetime)
        echo "%{lFg$FG B$BG} $TAGS %{rFg$FG B$BG} $RAM | $WIFI | $BT | $BAT | $DATETIME "
        sleep 1
    done
}

# Kill existing lemonbar
pkill lemonbar

# Launch bar only on laptop
if xrandr | grep -q "^$EXTERNAL connected"; then
    lemonbar -o "$LAPTOP" -g ${WIDTH}x${HEIGHT}+${X}+${Y} -B "$BG" -F "$FG" -f "$FONT" -n "laptop_bar" < <(gen_with_ext) &
else
    lemonbar -o "$LAPTOP" -g ${WIDTH}x${HEIGHT}+${X}+${Y} -B "$BG" -F "$FG" -f "$FONT" -n "laptop_bar" < <(gen_no_ext) &
fi
